import React, { Component } from 'react'
import NewsItem from './NewsItem'

export class News extends Component {
  
  constructor(){ //it made when object of this class is made
  super();
  console.log("Hello I am a constructor from news component")
  this.state={
    //articles: this.articles, --> this won't be applied now as we removed all articles now and you can refer those sample news articles in articlesInNews.txt
    articles:[],
    loading:false
  }
  }

  async componentDidMount(){ //async waits for completing or resolving some promises
    //lifecycle method
    //only runs after render function
    console.log("cdm")
    let url="https://newsapi.org/v2/top-headlines?country=in&apiKey=b63d4204bd364847a7e37058e4f94941";
    let data=await fetch(url); //promise
    let parsedData=await data.json()
    console.log(parsedData);
    this.setState({articles: parsedData.articles})
  }
  //async function can wait inside its body To resolve some promises like the data we got, if we want to convert it to text Or if we want to parse it into json we can do that


render() {
  console.log("render")
    return (
    <div className='container my-3'>
      <h2>NewsDose - Top Headlines</h2>
        <div className='row'>
          {this.state.articles.map((element)=>{
          return <div className='col-md-4' key={element.url}>
            This is a News Component
            {/* <NewsItem title={element.title.slice(0,44)} description={element.description.slice(0,88)} imageUrl={element.urlToImage} newsUrl={element.url}/> */}
            {/* <NewsItem title={element.title} description={element.description} imageUrl={element.urlToImage} newsUrl={element.url}/> */}
            <NewsItem title={element.title?element.title.slice(0,44):" "} description={element.description?element.description.slice(0,88):" "} imageUrl={element.urlToImage} newsUrl={element.url}/>
          </div>
          })}
        </div>
       </div>
    )
  } 
}

export default News

//In bootstrap there is grid of 12 so here we writing md-4 means these 3 containers would be aligning equally in container
//also this div's image url won't be hard coded
//unique key prop means is that whenever you use .map to iterate the elements, so you have to give unique key to every element
//for checking the limit of character and slice them check out textutils react app :))
// render will be running first Then componentDidMount() will run And firstly constructor is running.
//after h2 {/* {this.state.articles.map((element)=>{console.log(element)})} */}