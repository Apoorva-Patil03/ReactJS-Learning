import './App.css';
import React, { Component } from 'react'
import Navbar from './components/Navbar'
import News from './components/News';
//import NewsItem from './components/NewsItem';

export class App extends Component {
    //c='John';
  render() {
    return (
      <div>
        {/* Hello, My first class based component named {this.c} which is actually a variable of class 'this' and it makes manipulation of functions a bit easier! */}
        <Navbar/>
        <News/>
      </div>
    )
  }
}

export default App
//render is a life cycle component which runs for rendering all html on react app