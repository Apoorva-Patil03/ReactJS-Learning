
    blogs=[
        {
            title:"How to get started with python",
            content:"This is content python",
            slug:"python-learn"
        },
        {
            title:"How to get started with CSS",
            content:"This is content CSS",
            slug:"CSS-learn"

        },
        {
            title:"How to get started with JS",
            content:"This is content JS",
            slug:"JS-learn"

        },
        {
            title:"How to get started with HTML",
            content:"This is content HTML",
            slug:"HTML-learn"

        }
    ]
//slug is content besides title and content (part which most likely ignored while reading URL)

module.exports=blogs;