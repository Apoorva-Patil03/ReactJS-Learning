//here we save all routes for router and we are making different folders so that function implementation would be so much organized
const express = require('express')
const path = require('path')
const blogs=require('../data/blogs')

const router =express.Router()

router.get('/',(req, res)=>{
   // res.sendFile(path.join(__dirname, '../templates/index.html')) //we use ../ when we want to come out of folder by one step
   res.render('../home');
})
 
router.get('/blog',(req, res)=>{
    // blogs.forEach(e => {
    //     console.log(e.title) //by running it all 'titles' will appear in terminal
    // });
    res.sendFile(path.join(__dirname, '../templates/bloghome.html')) //we use ../ when we want to come out of folder by one step
})

router.get('/blogpost/:slug',(req, res)=>{
    //console.log(req.params.slug)
    myBlog=blogs.filter((e)=>{
        return e.slug=req.params.slug
    }) 
   console.log(myBlog)
    //we return element that would return true

    //In this way we would be able to make many endpoints at same point
    // blogs.forEach(e => {
    //     console.log(e.title) //by running it all 'titles' will appear in terminal
    // });
    res.sendFile(path.join(__dirname, '../templates/blogpage.html')) //we use ../ when we want to come out of folder by one step
})


module.exports=router

//In similar way we can actually connect database to nodeJS with help of Mongoose 
//we can use pug which is template engine for expressJS but syntax is deviated a bit from html so we instead of pug
//we can use handle bar
//we have to organize all files we using here and all JS variables must be sent to template for this we had to make or use template engine
//this can get it from express handlebars also visit a github page related to it  :--> https://github.com/express-handlebars
//and handlebars is one more site which can be helpful as template engine in Java