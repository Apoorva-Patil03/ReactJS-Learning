const express = require('express')
var engine =require('express-handlebars');



const path =require('path')
const app = express()
const port = 3000

app.engine('handlebars', engine());
app.set('view engine', 'handlebars');

app.use(express.static(path.join(__dirname,"static"))) //dirname=variable, static=string (static would serve as static file folder of html css files)
app.use('/',require(path.join(__dirname,'routes/blog.js' )))

// app.get('/', (req, res) => {
//   //res.send('Hello World!')
//   res.sendFile()
// })

// app.get('/about', (req, res) => {
//   //res.send('about')
//   //res.sendFile(path.join(__dirname,'index.html')) 
//   //res.status(500) 
//   res.json({"Name":"Apoorva"}) 
// }) 

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`) //to create direct link
})

//we here install nodemon as devdependancy(-d) (for using only for development not for app building) not as globally (-g)
//please do see everything about (Express) handlebars from 45:00 in video :--> https://www.youtube.com/watch?v=7H_QH9nipNs&list=LL&index=18&ab_channel=CodeWithHarry 