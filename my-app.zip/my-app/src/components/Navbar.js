import React from 'react'
import PropTypes from 'prop-types'

export default function Navbar(props) {
  return (
    // <div>
    //   Hello I am a Navbar
    // </div>
    <nav className={`navbar navbar-expand-lg navbar-${props.mode} bg-${props.mode}`}>  
    {/* Use of template literal */}
    {/* we can make navbar dark by replacing light here by dark */}
    <div className="container-fluid">
    <a className="navbar-brand" href="/">{props.title}</a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          {/* <Link className="nav-link active" aria-current="page" to="/">Home</Link> */}
          {/* <a className="nav-link active" aria-current="page" href="/">Home</a> */}
          <a className="nav-link active" aria-current="page" href="/">Home</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" href="/">{props.aboutText}</a>
        </li>
        <li className="nav-item dropdown">
          {/* <a className="nav-link dropdown-toggle" href="/" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a> */}
          <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a className="dropdown-item" href="/">Action</a></li>
            <li><a className="dropdown-item" href="/">Another action</a></li>
            <li><hr className="dropdown-divider"/></li>  
            {/* hr tag don't have ending tag so use slash to show it in jsx as jsx requires compulsory tag termination */}
            <li><a className="dropdown-item" href="/">Something else here</a></li>
          </ul>
        </li>
        <li className="nav-item">
          {/* <a className="nav-link disabled" href="/" tabIndex="-1" aria-disabled="true">Disabled</a>  */}
          <link className="nav-link " to="/about" tabIndex="-1" aria-disabled="true">Disabled</link> 
          {/* always use camelcase as shown in tabIndex to avoid warnings */}
        </li>
      </ul>
      <div className='d-flex'>
      {/* <div className='bg-primary rounded mx-2' onClick={props.toggleMode('primary')} style={{height:'30px', width:'30px'}}></div>  --->as we can't do this because it will call function directly onclick need a function not function call*/} 
      <div className='bg-primary rounded mx-2' onClick={()=>props.toggleMode('primary')} style={{height:'30px', width:'30px',cursor:'pointer'}}></div>
      <div className='bg-danger rounded mx-2' onClick={()=>props.toggleMode('danger')} style={{height:'30px', width:'30px',cursor:'pointer'}}></div>
      <div className='bg-success rounded mx-2' onClick={()=>props.toggleMode('success')} style={{height:'30px', width:'30px',cursor:'pointer'}}></div>
      <div className='bg-warning rounded mx-2' onClick={()=>props.toggleMode('warning')} style={{height:'30px', width:'30px',cursor:'pointer'}}></div>
      <div className='bg-warning rounded mx-2' onClick={()=>props.toggleMode('light')} style={{height:'30px', width:'30px',cursor:'pointer'}}></div>
      <div className='bg-warning rounded mx-2' onClick={()=>props.toggleMode('dark')} style={{height:'30px', width:'30px',cursor:'pointer'}}></div>
      </div>

      
      {/* <form className="d-flex">
        <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
        <button className="btn btn-outline-success" type="submit">Search</button>
      </form> */}
      {/* <div className="form-check form-switch text-light"> */}
      {/* <div className={`form-check form-switch text-${props.mode===`light`?`dark`:`light`}`}> */}
        {/* when I use backtick in Java Script, than I can use any variable by using $ or curly bracket. This is a variable and it has a ternary operator in it. And it says that, if mode of prop is dark than it should become light. and if mode of prop is light than it should become dark. */}
      {/* <input className="form-check-input" onClick={()=>props.toggleMode(null)} type="checkbox" role="switch" id="flexSwitchCheckDefault"/> */}
      {/* <label className="form-check-label" htmlfor="flexSwitchCheckDefault">Enable Dark Mode</label> */}
      {/* <label className="form-check-label" htmlfor="flexSwitchCheckDefault">Toggle Mode</label> */}
      {/* </div> */}
    </div>
  </div>
</nav>
  )
}

Navbar.propTypes={ //takes camelcase 
    // title:PropTypes.string,
    title:PropTypes.string.isRequired, //then we had to give value for title here if default is not present or error will occur here
    aboutText:PropTypes.string
}

Navbar.defaultProps={ //takes camelcase 
    title:'Set title here',
    aboutText:'About'
}
//this is an object which acts as restrictor

//rfc --> react function based components
//we turned code of navbar in reusable navbar file
//we always had to pass title and details/text like key and value
//for routing also we changed a--href tags to link--to tags
//refer this video for this:https://www.youtube.com/watch?v=Fi75tq9JikI&list=PLu0W_9lII9agx66oZnT6IyhcMIbUMNMdt&index=17&ab_channel=CodeWithHarry
//once you add bg-primary or bg-danger in your body, now if you add any background class it will be ignored until you remove old class
//reload, in my body means document.body it doesn't have any class of background now, as I click here it shows bg-danger so it shows red, now if I click here like this then bg-warning is added in body but bg-danger didn't get removed and it was added first so it will show red only until you can't remove bg-danger
// I will write a function to fix this, removeBodyClasses it will remove all the classes from my document.